package com.example.music_player_app.ui.theme

import androidx.compose.ui.graphics.Color

val Grey = Color(0xFF1C1C1C)
val Pink80 = Color(0xFFEFB8C8)
val Pink40 = Color(0xFF7D5260)
