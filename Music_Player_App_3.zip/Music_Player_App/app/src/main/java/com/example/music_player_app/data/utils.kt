package com.example.music_player_app.data

val songsList: List<Song> = listOf(
    Song(
        imageUrl = "https://cdn.pixabay.com/audio/2022/05/27/23-51-43-941_200x200.jpg",
        media = "https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3?filename=lofi-study-112191.mp3",
        duration = "2:27",
        title = "Lofi Study",
        artist = "FassSounds"
    ),

    Song(
        imageUrl = "https://cdn.pixabay.com/audio/2022/09/02/21-42-13-13_200x200.jpg",
        media = "https://cdn.pixabay.com/download/audio/2022/09/02/audio_72502a492a.mp3?filename=empty-mind-118973.mp3",
        duration = "2:55",
        title = "Empty mind",
        artist = "Lofi hour"
    )
)